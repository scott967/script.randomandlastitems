# This program is Free Software see LICENSE file for details
""" Skins use to provide random or recent added library info for widgets

Invoke with RunScript() built-in command.  Script will return library info
via Window Properties.  See README.txt for more.

Typical usage example:

    On Home window:

    <onload>RunScript(script.randomandlastitems,limit=12,method=Last,
    playlist="some playlist")</onload>

    This will get library info for the 12 newest (date added) playlist itmes
    and return as window properties.  It runs as a one-shot (not a service)

    Does not provide results for artist or mixed smart playlists
"""


import json
import os
import random
import sys
import time
import urllib.request
from operator import itemgetter
from typing import List, Tuple
from xml.dom.minidom import parse

import xbmc
import xbmcvfs
from lib import *

def log(txt: str) -> None:
    """utility writes info to Kodi debug level log

    Args:
        txt (str): text to log

    Returns: None
    """
    message = f'{ADDONNAME}: {txt}'
    xbmc.log(msg=message, level=xbmc.LOGDEBUG)


def _getPlaylistType() -> None:
    """sets global variables for a playlist

        Returns:  None
    """
    _doc = parse(xbmcvfs.translatePath(RALI_GLOBALS['PLAYLIST']))
    _type = _doc.getElementsByTagName('smartplaylist')[0].attributes.getNamedItem(
        'type').nodeValue  # type: ignore
    if _type == 'movies':
        RALI_GLOBALS['TYPE'] = 'Movie'
    if _type == 'musicvideos':
        RALI_GLOBALS['TYPE'] = 'MusicVideo'
    if _type == 'episodes' or _type == 'tvshows':
        RALI_GLOBALS['TYPE'] = 'Episode'
    if _type == 'songs' or _type == 'albums':
        RALI_GLOBALS['TYPE'] = 'Music'
    if _type == "artists" or _type == 'mixed':
        RALI_GLOBALS['TYPE'] = 'Invalid'
    # get playlist name
    _name = ''
    if _doc.getElementsByTagName('name'):
        try:
            _name = _doc.getElementsByTagName(
                'name')[0].firstChild.nodeValue  # type: ignore
        except Exception:
            _name = ''
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Name', str(_name))
    # get playlist order
    if RALI_GLOBALS['METHOD'] == 'Playlist':
        if _doc.getElementsByTagName('order'):
            RALI_GLOBALS['SORTBY'] = _doc.getElementsByTagName('order')[0].firstChild.nodeValue
            if _doc.getElementsByTagName('order')[0].attributes.getNamedItem('direction').nodeValue == 'descending':
                RALI_GLOBALS['REVERSE'] = True
        else:
            RALI_GLOBALS['METHOD'] = ''


def _timeTook(t: float) -> str:
    """ Utility gets elapsed time for query (used for logging)

    Args:
        t (float): start time

    Returns:
        str: elapsed time to .001 sec
    """
    t = time.time() - t
    if t >= 60:
        return '%.3fm' % (t / 60.0)
    return '%.3fs' % (t)


def _watchedOrResume(_total: int, _watched: int, _unwatched: int, _result: list,
                     _file: dict) -> Tuple[int, int, int, list]:
    """Gets watched / in progress status for a library item and increments counters

    RESUME and UNWATCHED are bools to determine when an item is valid for inclusion
    in the _result item list.  eg, if UNWATCHED is true any watched item is
    excluded.

    Args:
        _total (int): cumulative number of items
        _watched (int): cumulative number of watched items
        _unwatched (int): cumulative number of unwatched items
        _result (list): cumulative list of processed library items
        _file (dict): a library item to evaluate watched / in progress status

    Returns:
        Tuple[int, int, int, list]: updated totals and item list
    """
    _total += 1
    _playcount: int = _file['playcount']
    _resume: int = _file['resume']['position']
    # Add Watched flag and counter for episodes
    if _playcount == 0:
        _file['watched'] = 'False'
        _unwatched += 1
    else:
        _file['watched'] = 'True'
        _watched += 1
    if ((RALI_GLOBALS['UNWATCHED'] == 'False' and RALI_GLOBALS['RESUME'] == 'False')
        or (RALI_GLOBALS['UNWATCHED'] == 'True' and _playcount == 0)
            or (RALI_GLOBALS['RESUME'] == 'True' and _resume != 0) and _file.get('dateadded')):
        _result.append(_file)
    return _total, _watched, _unwatched, _result


def _getMovies() -> None:
    """retrieves movie info from Kodi library and sets properties

    If a movie playlist is not provided uses movie titles library node

    Returns:
        None
    """
    _result: List[dict] = []
    _total = 0
    _unwatched = 0
    _watched = 0
    # Request database using JSON
    if RALI_GLOBALS['PLAYLIST'] == '':
        RALI_GLOBALS['PLAYLIST'] = 'videodb://movies/titles/'
    if JSON_RPC_NEXUS:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            f'"params": {{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "video", '
            '"properties": '
            '["title", '
            '"originaltitle", '
            '"playcount", '
            '"year", '
            '"genre", '
            '"studio", '
            '"country", '
            '"tagline", '
            '"plot", '
            '"runtime", '
            '"file", '
            '"plotoutline", '
            '"lastplayed", '
            '"trailer", '
            '"rating", '
            '"userrating", '
            '"resume", '
            '"art", '
            '"streamdetails", '
            '"mpaa", '
            '"director", '
            '"dateadded"]'
            '}, '
            '"id": 1}')
    else:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            f'"params": {{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "video", '
            '"properties": '
            '["title", '
            '"originaltitle", '
            '"playcount", '
            '"year", '
            '"genre", '
            '"studio", '
            '"country", '
            '"tagline", '
            '"plot", '
            '"runtime", '
            '"file", '
            '"plotoutline", '
            '"lastplayed", '
            '"trailer", '
            '"rating", '
            '"resume", '
            '"art", '
            '"streamdetails", '
            '"mpaa", '
            '"director", '
            '"dateadded"]'
            '}, '
            '"id": 1}')
    _json_pl_response: dict = json.loads(_json_query)
    # If request return some results as _files
    _files: dict = _json_pl_response.get('result', {}).get('files')
    if _files:
        for _item in _files:
            if MONITOR.abortRequested():
                return
            if _item['filetype'] == 'directory':
                if JSON_RPC_NEXUS:
                    _json_query = xbmc.executeJSONRPC(
                        '{"jsonrpc": "2.0", '
                        '"method": "Files.GetDirectory", '
                        '"params": '
                        f'{{"directory": "{_item["file"]}", '
                        '"media": "video", '
                        '"properties": '
                        '["title", '
                        '"originaltitle", '
                        '"playcount", '
                        '"year", '
                        '"genre", '
                        '"studio", '
                        '"country", '
                        '"tagline", '
                        '"plot", '
                        '"runtime", '
                        '"file", '
                        '"plotoutline", '
                        '"lastplayed", '
                        '"trailer", '
                        '"rating", '
                        '"userrating", '
                        '"resume", '
                        '"art", '
                        '"streamdetails", '
                        '"mpaa", '
                        '"director", '
                        '"dateadded"]'
                        '}, '
                        '"id": 1}')
                else:
                    _json_query = xbmc.executeJSONRPC(
                        '{"jsonrpc": "2.0", '
                        '"method": "Files.GetDirectory", '
                        '"params": '
                        f'{{"directory": "{_item["file"]}", '
                        '"media": "video", '
                        '"properties": '
                        '["title", '
                        '"originaltitle", '
                        '"playcount", '
                        '"year", '
                        '"genre", '
                        '"studio", '
                        '"country", '
                        '"tagline", '
                        '"plot", '
                        '"runtime", '
                        '"file", '
                        '"plotoutline", '
                        '"lastplayed", '
                        '"trailer", '
                        '"rating", '
                        '"resume", '
                        '"art", '
                        '"streamdetails", '
                        '"mpaa", '
                        '"director", '
                        '"dateadded"]'
                        '}, '
                        '"id": 1}')
                _json_set_response: dict = json.loads(_json_query)
                _movies: List[dict] = _json_set_response.get(
                    'result', {}).get('files') or []
                if not _movies:
                    log(f'## MOVIESET {_item["file"]} COULD NOT BE LOADED ##')
                    log(f'JSON RESULT {_json_set_response}')
                for _movie in _movies:
                    if MONITOR.abortRequested():
                        return
                    _playcount: int = _movie['playcount']
                    if RALI_GLOBALS['RESUME'] == 'True':
                        _resume: int = _movie['resume']['position']
                    else:
                        _resume = 0
                    _total += 1
                    if _playcount == 0:
                        _unwatched += 1
                    else:
                        _watched += 1
                    if ((RALI_GLOBALS['UNWATCHED'] == 'False' and RALI_GLOBALS['RESUME'] == 'False')
                        or (RALI_GLOBALS['UNWATCHED'] == 'True' and _playcount == 0)
                            or (RALI_GLOBALS['RESUME'] == 'True' and _resume != 0)):
                        _result.append(_movie)
            else:
                _playcount = _item['playcount']
                _total += 1
                if RALI_GLOBALS['RESUME'] == 'True':
                    _resume = _item['resume']['position']
                else:
                    _resume = 0
                if _playcount == 0:
                    _unwatched += 1
                else:
                    _watched += 1
                if ((RALI_GLOBALS['UNWATCHED'] == 'False' and RALI_GLOBALS['RESUME'] == 'False')
                    or (RALI_GLOBALS['UNWATCHED'] == 'True' and _playcount == 0)
                        or (RALI_GLOBALS['RESUME'] == 'True' and _resume != 0)):
                    _result.append(_item)
        _setVideoProperties(_total, _watched, _unwatched)
        _count = 0
        if RALI_GLOBALS['METHOD'] == 'Last':
            _result = sorted(_result, key=itemgetter(
                'dateadded'), reverse=True)
        elif RALI_GLOBALS['METHOD'] == 'Playlist':
            _result = sorted(_result, key=itemgetter(
                RALI_GLOBALS['SORTBY']), reverse=RALI_GLOBALS['REVERSE'])
        else:
            random.shuffle(_result)
        for _movie in _result:
            if MONITOR.abortRequested():
                return
            if _count == RALI_GLOBALS['LIMIT']:
                break
            _count += 1
            _json_query = xbmc.executeJSONRPC(
                '{"jsonrpc": "2.0", '
                '"method": "VideoLibrary.GetMovieDetails", '
                '"params": '
                f'{{"properties": ["streamdetails"], "movieid":{_movie["id"]}}}, '
                '"id": 1}')
            _json_query = json.loads(_json_query)
            if 'result' in _json_query and 'moviedetails' in _json_query['result']:
                item = _json_query['result']['moviedetails']
                _movie['streamdetails'] = item['streamdetails']
            if _movie['resume']['position'] > 0 and float(_movie['resume']['total']) > 0:
                resume = 'true'
                played = f'{int((float(_movie["resume"]["position"]) / float(_movie["resume"]["total"])) * 100)}%'
                playedasint = f'{int((float(_movie["resume"]["position"]) / float(_movie["resume"]["total"])) * 100)}'
            else:
                resume = 'false'
                played = '0%'
                playedasint = '0'
            if _movie['playcount'] >= 1:
                watched = 'true'
            else:
                watched = 'false'
            path = media_path(_movie['file'])
            play = 'RunScript(' + ADDONID + ',movieid=' + (
                str(_movie.get('id')) + ')')
            art = _movie['art']
            streaminfo = media_streamdetails(_movie['file'].lower(),
                                             _movie['streamdetails'])
            # Get runtime from streamdetails or from NFO
            if streaminfo['duration'] != 0:
                runtime = str(int((streaminfo['duration'] / 60) + 0.5))
            else:
                if isinstance(_movie['runtime'], int):
                    runtime = str(int((_movie['runtime'] / 60) + 0.5))
                else:
                    runtime = _movie['runtime']
            # Set window properties
            # autopep8:off
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.DBID'            , str(_movie.get('id','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title'           , _movie.get('title',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.OriginalTitle'   , _movie.get('originaltitle',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Year'            , str(_movie.get('year','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Genre'           , ' / '.join(_movie.get('genre','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Studio'          , ' / '.join(_movie.get('studio','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Country'         , ' / '.join(_movie.get('country','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Plot'            , _movie.get('plot',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.PlotOutline'     , _movie.get('plotoutline',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Tagline'         , _movie.get('tagline',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Runtime'         , runtime)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Rating'          , str(round(float(_movie.get('rating','0')),1)))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.UserRating'      , str(_movie.get('userrating','0')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Trailer'         , _movie.get('trailer',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.MPAA'            , _movie.get('mpaa',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Director'        , ' / '.join(_movie.get('director','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(thumb)'      , art.get('thumb',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(poster)'     , art.get('poster',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(fanart)'     , art.get('fanart',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(clearlogo)'  , art.get('clearlogo',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(clearart)'   , art.get('clearart',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(landscape)'  , art.get('landscape',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(banner)'     , art.get('banner',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(discart)'    , art.get('discart',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Resume'          , resume)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.PercentPlayed'   , played)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Played'          , playedasint)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Watched'         , watched)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.File'            , _movie.get('file',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Path'            , path)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Play'            , play)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoCodec'      , streaminfo['videocodec'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoResolution' , streaminfo['videoresolution'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoAspect'     , streaminfo['videoaspect'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.AudioCodec'      , streaminfo['audiocodec'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.AudioChannels'   , str(streaminfo['audiochannels']))
            # autopep8:on

        if _count != RALI_GLOBALS['LIMIT']:
            while _count < RALI_GLOBALS['LIMIT']:
                _count += 1
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title', '')
    else:
        log(f'## PLAYLIST {RALI_GLOBALS["PLAYLIST"]} COULD NOT BE LOADED ##')
        log(f'JSON RESULT {_json_pl_response}')


def _getMusicVideosFromPlaylist() -> None:
    """ retrieves music video info from Kodi library and sets properties

    If a music video playlist is not provided uses music video titles node
    """
    _result = []
    _total = 0
    _unwatched = 0
    _watched = 0
    # Request database using JSON
    if RALI_GLOBALS['PLAYLIST'] == '':
        RALI_GLOBALS['PLAYLIST'] = 'musicdb://musicvideos/titles'
    if JSON_RPC_NEXUS:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "video", '
            '"properties": '
            '["title", '
            '"playcount", '
            '"year", '
            '"genre", '
            '"studio", '
            '"album", '
            '"artist",  '
            '"track", '
            '"plot", '
            '"tag", '
            '"rating", '
            '"userrating", '
            '"runtime", '
            '"file", '
            '"lastplayed", '
            '"resume", '
            '"art", '
            '"streamdetails", '
            '"director", '
            '"dateadded"]'
            '}, '
            '"id": 1}')
    else:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "video", '
            '"properties": '
            '["title", '
            '"playcount", '
            '"year", '
            '"genre", '
            '"studio", '
            '"album", '
            '"artist",  '
            '"track", '
            '"plot", '
            '"tag", '
            '"rating", '
            '"runtime", '
            '"file", '
            '"lastplayed", '
            '"resume", '
            '"art", '
            '"streamdetails", '
            '"director", '
            '"dateadded"]'
            '}, '
            '"id": 1}')
    _json_pl_response: dict = json.loads(_json_query)
    # If request return some results
    _files = _json_pl_response.get('result', {}).get('files')
    if _files:
        for _item in _files:
            if MONITOR.abortRequested():
                return
            _playcount = _item['playcount']
            if RALI_GLOBALS['RESUME'] == 'True':
                _resume = _item['resume']['position']
            else:
                _resume = 0
            _total += 1
            if _playcount == 0:
                _unwatched += 1
            else:
                _watched += 1
            if ((RALI_GLOBALS['UNWATCHED'] == 'False' and RALI_GLOBALS['RESUME'] == 'False')
                or (RALI_GLOBALS['UNWATCHED'] == 'True' and _playcount == 0)
                    or (RALI_GLOBALS['RESUME'] == 'True' and _resume != 0)):
                _result.append(_item)
        _setVideoProperties(_total, _watched, _unwatched)
        _count = 0
        if RALI_GLOBALS['METHOD'] == 'Last':
            _result = sorted(_result, key=itemgetter(
                'dateadded'), reverse=True)
        elif RALI_GLOBALS['METHOD'] == 'Playlist':
            _result = sorted(_result, key=itemgetter(
                RALI_GLOBALS['SORTBY']), reverse=RALI_GLOBALS['REVERSE'])
        else:
            random.shuffle(_result)
        for _musicvid in _result:
            if MONITOR.abortRequested():
                return
            if _count == RALI_GLOBALS['LIMIT']:
                break
            _count += 1
            _json_query = xbmc.executeJSONRPC(
                '{"jsonrpc": "2.0", '
                '"method": "VideoLibrary.GetMusicVideoDetails", '
                '"params": '
                f'{{"properties": ["streamdetails"], "musicvideoid":{_musicvid["id"]} }}, '
                '"id": 1}')
            _json_query = json.loads(_json_query)
            if 'musicvideodetails' in _json_query['result']:
                item = _json_query['result']['musicvideodetails']
                _musicvid['streamdetails'] = item['streamdetails']
            if _musicvid['resume']['position'] > 0 and float(_musicvid['resume']['total']) > 0:
                resume = 'true'
                played = f'{int((float(_musicvid["resume"]["position"]) / float(_musicvid["resume"]["total"])) * 100)}%'
                playedasint = f'{int((float(_musicvid["resume"]["position"]) / float(_musicvid["resume"]["total"])) * 100)}'
            else:
                resume = 'false'
                played = '0%'
                playedasint = '0'
            if _musicvid['playcount'] >= 1:
                watched = 'true'
            else:
                watched = 'false'
            path = media_path(_musicvid['file'])
            play = 'RunScript(' + ADDONID + \
                ',musicvideoid=' + str(_musicvid.get('id')) + ')'
            art = _musicvid['art']
            streaminfo = media_streamdetails(_musicvid['file'].lower(),
                                             _musicvid['streamdetails'])
            # Get runtime from streamdetails or from NFO
            runtimesecs = ""
            if streaminfo['duration'] != 0:
                runtime = str(int((streaminfo['duration'] / 60) + 0.5))
                runtimesecs = (str(streaminfo['duration'] // 60) + ':'
                               + f"{streaminfo['duration'] % 60:02d}")
            else:
                if isinstance(_musicvid['runtime'], int):
                    runtime = str(int((_musicvid['runtime'] / 60) + 0.5))
                    runtimesecs = (str(_musicvid['runtime'] // 60) + ':'
                                   + f"{_musicvid['runtime'] % 60:02d}")
                else:
                    runtime = _musicvid['runtime']
            # Set window properties
            # autopep8:off
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.DBID'            , str(_musicvid.get('id')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title'           , _musicvid.get('title',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Year'            , str(_musicvid.get('year','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Genre'           , ' / '.join(_musicvid.get('genre','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Studio'          , ' / '.join(_musicvid.get('studio','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Artist'          , ' / '.join(_musicvid.get('artist','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Album'           , _musicvid.get('album',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Track'           , str(_musicvid.get('track','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Rating'          , str(_musicvid.get('rating','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.UserRating'      , str(_musicvid.get('userrating','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Plot'            , _musicvid.get('plot',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Tag'             , ' / '.join(_musicvid.get('tag','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Runtime'         , runtime)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Runtimesecs'     , runtimesecs)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Director'        , ' / '.join(_musicvid.get('director','')))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(thumb)'      , art.get('thumb',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(poster)'     , art.get('poster',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(fanart)'     , art.get('fanart',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(clearlogo)'  , art.get('clearlogo',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(clearart)'   , art.get('clearart',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(landscape)'  , art.get('landscape',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(banner)'     , art.get('banner',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(discart)'    , art.get('discart',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Resume'          , resume)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.PercentPlayed'   , played)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Played'          , playedasint)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Watched'         , watched)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.File'            , _musicvid.get('file',''))
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Path'            , path)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Play'            , play)
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoCodec'      , streaminfo['videocodec'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoResolution' , streaminfo['videoresolution'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoAspect'     , streaminfo['videoaspect'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.AudioCodec'      , streaminfo['audiocodec'])
            _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.AudioChannels'   , str(streaminfo['audiochannels']))
            # autopep8:on

        if _count != RALI_GLOBALS['LIMIT']:
            while _count < RALI_GLOBALS['LIMIT']:
                _count += 1
                _setProperty(f"{RALI_GLOBALS['PROPERTY']}.{_count}.Title", '')
    else:
        log(f'## PLAYLIST {RALI_GLOBALS["PLAYLIST"]} COULD NOT BE LOADED ##')
        log(f'JSON RESULT {_json_pl_response}')


def _getEpisodesFromPlaylist() -> None:
    """retrieves episodes playlist info from Kodi library and sets properties

    """
    _result = []
    _total = 0
    _unwatched = 0
    _watched = 0
    _tvshows = 0
    _tvshowid = []
    # Request database using JSON
    if JSON_RPC_NEXUS:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "video", '
            '"properties": '
            '["title", '
            '"playcount", '
            '"season", '
            '"episode", '
            '"showtitle", '
            '"plot", '
            '"file", '
            '"studio", '
            '"mpaa", '
            '"rating", '
            '"userrating", '
            '"resume", '
            '"runtime", '
            '"tvshowid", '
            '"art", '
            '"streamdetails", '
            '"firstaired", '
            '"dateadded"] '
            '}, '
            '"id": 1}')
    else:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "video", '
            '"properties": '
            '["title", '
            '"playcount", '
            '"season", '
            '"episode", '
            '"showtitle", '
            '"plot", '
            '"file", '
            '"studio", '
            '"mpaa", '
            '"rating", '
            '"resume", '
            '"runtime", '
            '"tvshowid", '
            '"art", '
            '"streamdetails", '
            '"firstaired", '
            '"dateadded"] '
            '}, '
            '"id": 1}')
    _json_pl_response = json.loads(_json_query)
    _files = _json_pl_response.get('result', {}).get('files')
    if _files:
        for _file in _files:
            if MONITOR.abortRequested():
                return
            if _file['type'] == 'tvshow':
                _tvshows += 1
                # Playlist return TV Shows - Need to get episodes
                if JSON_RPC_NEXUS:
                    _json_query = xbmc.executeJSONRPC(
                        '{"jsonrpc": "2.0", '
                        '"method": "VideoLibrary.GetEpisodes", '
                        '"params": '
                        f'{{ "tvshowid": {_file["id"]}, '
                        '"properties": '
                        '["title", '
                        '"playcount", '
                        '"season", '
                        '"episode", '
                        '"showtitle", '
                        '"plot", '
                        '"file", '
                        '"rating", '
                        '"userrating", '
                        '"resume", '
                        '"runtime", '
                        '"tvshowid", '
                        '"art", '
                        '"streamdetails", '
                        '"firstaired", '
                        '"dateadded"] '
                        '}, '
                        '"id": 1}')
                else:
                    _json_query = xbmc.executeJSONRPC(
                        '{"jsonrpc": "2.0", '
                        '"method": "VideoLibrary.GetEpisodes", '
                        '"params": '
                        f'{{ "tvshowid": {_file["id"]}, '
                        '"properties": '
                        '["title", '
                        '"playcount", '
                        '"season", '
                        '"episode", '
                        '"showtitle", '
                        '"plot", '
                        '"file", '
                        '"rating", '
                        '"resume", '
                        '"runtime", '
                        '"tvshowid", '
                        '"art", '
                        '"streamdetails", '
                        '"firstaired", '
                        '"dateadded"] '
                        '}, '
                        '"id": 1}')
                _json_response = json.loads(_json_query)
                _episodes = _json_response.get('result', {}).get('episodes')
                if _episodes:
                    for _episode in _episodes:
                        if MONITOR.abortRequested():
                            return
                        # Add TV Show fanart and thumbnail for each episode
                        art = _episode['art']
                        # Add episode ID when playlist type is TVShow
                        _episode['id'] = _episode['episodeid']
                        _episode['tvshowfanart'] = art.get('tvshow.fanart')
                        _episode['tvshowthumb'] = art.get('thumb')
                        # Set MPAA and studio for all episodes
                        _episode['mpaa'] = _file['mpaa']
                        _episode['studio'] = _file['studio']
                        _total, _watched, _unwatched, _result = _watchedOrResume(
                            _total, _watched, _unwatched, _result, _episode)
                else:
                    log(
                        f'## PLAYLIST {RALI_GLOBALS["PLAYLIST"]} COULD NOT BE LOADED ##')
                    log(f'JSON RESULT {_json_response}')
            if _file['type'] == 'episode':
                _id = _file['tvshowid']
                if _id not in _tvshowid:
                    _tvshows += 1
                    _tvshowid.append(_id)
                # Playlist return TV Shows - Nothing else to do
                _total, _watched, _unwatched, _result = _watchedOrResume(
                    _total, _watched, _unwatched, _result, _file)
        _setVideoProperties(_total, _watched, _unwatched)
        _setTvShowsProperties(_tvshows)
        _count = 0
        if RALI_GLOBALS['METHOD'] == 'Last':
            _result = sorted(_result, key=itemgetter(
                'dateadded'), reverse=True)
        elif RALI_GLOBALS['METHOD'] == 'Playlist':
            _result = sorted(_result, key=itemgetter(
                RALI_GLOBALS['SORTBY']), reverse=RALI_GLOBALS['REVERSE'])
        else:
            random.shuffle(_result)
        for _episode in _result:
            if MONITOR.abortRequested():
                return
            if _count == RALI_GLOBALS['LIMIT']:
                break
            _count += 1
            '''
            if _episode.get('tvshowid'):
                _json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShowDetails", "params": { "tvshowid": %s, "properties": ["title", "fanart", "thumbnail"] }, "id": 1}' %(_episode['tvshowid']))
                _json_pl_response = json.loads(_json_query)
                _tvshow = _json_pl_response.get('result', {}).get('tvshowdetails')
            '''
            _setEpisodeProperties(_episode, _count)
        if _count != RALI_GLOBALS['LIMIT']:
            while _count < RALI_GLOBALS['LIMIT']:
                _count += 1
                _setEpisodeProperties(None, _count)
    else:
        log(f'# 01 # PLAYLIST {RALI_GLOBALS["PLAYLIST"]} COULD NOT BE LOADED ##')
        log(f'JSON RESULT {_json_pl_response}')


def _getEpisodes() -> None:
    """retrieves episode library node info from Kodi library and sets properties

    Returns:
        None
    """
    _result = []
    _total = 0
    _unwatched = 0
    _watched = 0
    _tvshows = 0
    _tvshowid = []
    # Request database using JSON
    if JSON_RPC_NEXUS:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "VideoLibrary.GetEpisodes", '
            '"params": '
            '{ "properties": '
            '["title", '
            '"playcount", '
            '"season", '
            '"episode", '
            '"showtitle", '
            '"plot", '
            '"file", '
            '"studio", '
            '"mpaa", '
            '"rating", '
            '"userrating", '
            '"resume", '
            '"runtime", '
            '"tvshowid", '
            '"art", '
            '"streamdetails", '
            '"firstaired", '
            '"dateadded"]'
            '}, '
            '"id": 1}')
    else:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "VideoLibrary.GetEpisodes", '
            '"params": '
            '{ "properties": '
            '["title", '
            '"playcount", '
            '"season", '
            '"episode", '
            '"showtitle", '
            '"plot", '
            '"file", '
            '"studio", '
            '"mpaa", '
            '"rating", '
            '"resume", '
            '"runtime", '
            '"tvshowid", '
            '"art", '
            '"streamdetails", '
            '"firstaired", '
            '"dateadded"]'
            '}, '
            '"id": 1}')
    _json_pl_response = json.loads(_json_query)
    # If request return some results
    _episodes = _json_pl_response.get('result', {}).get('episodes')
    if _episodes:
        for _item in _episodes:
            if MONITOR.abortRequested():
                return
            _id = _item['tvshowid']
            if _id not in _tvshowid:
                _tvshows += 1
                _tvshowid.append(_id)
            # Add episode ID
            _item['id'] = _item['episodeid']
            _total, _watched, _unwatched, _result = _watchedOrResume(
                _total, _watched, _unwatched, _result, _item)
        _setVideoProperties(_total, _watched, _unwatched)
        _setTvShowsProperties(_tvshows)
        _count = 0
        if RALI_GLOBALS['METHOD'] == 'Last':
            _result = sorted(_result, key=itemgetter(
                'dateadded'), reverse=True)
        elif RALI_GLOBALS['METHOD'] == 'Playlist':
            _result = sorted(_result, key=itemgetter(
                RALI_GLOBALS['SORTBY']), reverse=RALI_GLOBALS['REVERSE'])
        else:
            random.shuffle(_result)
        for _episode in _result:
            if MONITOR.abortRequested():
                return
            if _count == RALI_GLOBALS['LIMIT']:
                break
            _count += 1
            _setEpisodeProperties(_episode, _count)
        if _count != RALI_GLOBALS['LIMIT']:
            while _count < RALI_GLOBALS['LIMIT']:
                _count += 1
                _setEpisodeProperties(None, _count)
    else:
        log(f'## PLAYLIST {RALI_GLOBALS["PLAYLIST"]} COULD NOT BE LOADED ##')
        log(f'JSON RESULT {_json_pl_response}')


def _getMusicFromPlaylist() -> None:
    """gets albums/songs from an album/songs playlist and retrieves libary data for them

    The album details are provided as window properties.  If a playlist is not
    provided uses library songs node.  Artist and mixed playlists not supported
    """

    _result = []
    _artists = 0
    _artistsid = []
    _albums = 0
    _albumslist = []
    _albumsid = []
    _songs = 0
    _songslist = []
    # Request database using JSON
    if RALI_GLOBALS['PLAYLIST'] == '':
        RALI_GLOBALS['PLAYLIST'] = 'musicdb://songs/'
    # _json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Files.GetDirectory", "params": {"directory": "%s", "media": "music", "properties": ["title", "description", "albumlabel", "artist", "genre", "year", "thumbnail", "fanart", "rating", "userrating", "playcount", "dateadded"]}, "id": 1}' %(PLAYLIST))
    if RALI_GLOBALS['METHOD'] == 'Random':
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "music", '
            '"properties": ["dateadded"], '
            '"sort": {"method": "random"}}, '
            '"id": 1}')
    elif RALI_GLOBALS['METHOD'] == 'Last':
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "music", '
            '"properties": ["dateadded"], '
            '"sort": '
            '{"order": "descending", '
            '"method": "dateadded"}}, '
            '"id": 1}')
    elif RALI_GLOBALS['METHOD'] == 'Playlist':
        order = 'ascending'
        if RALI_GLOBALS['REVERSE']:
            order = 'descending'
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "music", '
            '"properties": ["dateadded"], '
            '"sort": '
            f'{{"order": "{order}", '
            f'"method": "{RALI_GLOBALS["SORTBY"]}"}}}}, '
            '"id": 1}')
    else:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "Files.GetDirectory", '
            '"params": '
            f'{{"directory": "{RALI_GLOBALS["PLAYLIST"]}", '
            '"media": "music", '
            '"properties": ["dateadded"]}, '
            '"id": 1}')
    _json_pl_response = json.loads(_json_query)
    # If request return some results
    _files: List[dict] = _json_pl_response.get('result', {}).get('files')
    #  Music type can be either album or song based on playlist type
    if _files and _files[0].get('type') == 'album':
        for _file in _files:
            if MONITOR.abortRequested():
                return
            if _file['type'] == 'album':
                _albumslist.append(_file)
                _albumid = _file['id']
                # Album playlist so get path from songs
                _json_query = xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0", '
                    '"method":"AudioLibrary.GetSongs", '
                    '"params":'
                    f'{{"filter":{{"albumid": {_albumid}}}, '
                    '"properties":["artistid"]}, '
                    '"id": 1}')
                _json_pl_response = json.loads(_json_query)
                _result = _json_pl_response.get('result', {}).get('songs')
                if _result:
                    _songs += len(_result)
                    _artistid = _result[0]['artistid']
                    if _artistid not in _artistsid:
                        _artists += 1
                        _artistsid.append(_artistid)
            # _albumid = _file.get('albumid', _file.get('id'))
            # _albumpath = os.path.split(_file['file'])[0]
            # _artistpath = os.path.split(_albumpath)[0]
            # _songs += 1
            '''
            if _albumid not in _albumsid:
                _file['id'] = _albumid
                _file['albumPath'] = _albumpath
                _file['artistPath'] = _artistpath
                _albumslist.append(_file)
                _albumsid.append(_albumid)
            '''
        _setMusicProperties(_artists, len(_files), _songs)
        if RALI_GLOBALS['METHOD'] == 'Last':
            _albumslist = sorted(
                _albumslist, key=itemgetter('dateadded'), reverse=True)
        else:
            random.shuffle(_albumslist)
        _count = 0
        for _album in _albumslist:
            if MONITOR.abortRequested():
                return
            if _count == RALI_GLOBALS['LIMIT']:
                break
            _count += 1
            _albumid = _album['id']
            if JSON_RPC_NEXUS:
                _json_query = xbmc.executeJSONRPC(
                    '{"jsonrpc": "2.0", '
                    '"method": "AudioLibrary.GetAlbumDetails", '
                    '"params":'
                    f'{{"albumid": {_albumid}, '
                    '"properties":'
                    '["title", '
                    '"description", '
                    '"albumlabel", '
                    '"theme", '
                    '"mood", '
                    '"style", '
                    '"type", '
                    '"artist", '
                    '"genre", '
                    '"year", '
                    '"thumbnail", '
                    '"fanart", '
                    '"rating", '
                    '"userrating", '
                    '"playcount"]}, '
                    '"id": 1}')
            else:
                _json_query = xbmc.executeJSONRPC(
                    '{"jsonrpc": "2.0", '
                    '"method": "AudioLibrary.GetAlbumDetails", '
                    '"params":'
                    f'{{"albumid": {_albumid}, '
                    '"properties":'
                    '["title", '
                    '"description", '
                    '"albumlabel", '
                    '"theme", '
                    '"mood", '
                    '"style", '
                    '"type", '
                    '"artist", '
                    '"genre", '
                    '"year", '
                    '"thumbnail", '
                    '"fanart", '
                    '"rating", '
                    '"playcount"]}, '
                    '"id": 1}')
            _json_pl_response = json.loads(_json_query)
            # If request return some results
            _album: dict = _json_pl_response.get(
                'result', {}).get('albumdetails')
            _setAlbumPROPERTIES(_album, _count)
        if _count <= RALI_GLOBALS['LIMIT']:
            while _count < RALI_GLOBALS['LIMIT']:
                _count += 1
                _setAlbumPROPERTIES(None, _count)
    elif _files and _files[0].get('type') == 'song':
        for _file in _files:
            if MONITOR.abortRequested():
                return
            _songid = _file['id']
            if JSON_RPC_NEXUS:
                _json_query = xbmc.executeJSONRPC(
                    '{"jsonrpc": "2.0", '
                    '"method": "AudioLibrary.GetSongDetails", '
                    '"params":'
                    f'{{"songid": {_songid}, '
                    '"properties":'
                    '["title", '
                    '"artist", '
                    '"artistid", '
                    '"dateadded", '
                    '"genre", '
                    '"year", '
                    '"rating", '
                    '"album", '
                    '"albumid", '
                    '"track", '
                    '"duration", '
                    '"comment", '
                    '"thumbnail", '
                    '"fanart", '
                    '"userrating", '
                    '"playcount"]}, '
                    '"id": 1}')
            else:
                _json_query = xbmc.executeJSONRPC(
                    '{"jsonrpc": "2.0", '
                    '"method": "AudioLibrary.GetSongDetails", '
                    '"params":'
                    f'{{"songid": {_songid}, '
                    '"properties":'
                    '["title", '
                    '"artist", '
                    '"artistid", '
                    '"dateadded", '
                    '"genre", '
                    '"year", '
                    '"rating", '
                    '"album", '
                    '"albumid", '
                    '"track", '
                    '"duration", '
                    '"comment", '
                    '"thumbnail", '
                    '"fanart", '
                    '"playcount"]}, '
                    '"id": 1}')
            _json_pl_response = json.loads(_json_query)
            _result: dict = _json_pl_response.get(
                'result', {}).get('songdetails')
            if _result:
                _songslist.append(_result)
                for _artistid in _result['artistid']:
                    if _artistid not in _artistsid:
                        _artists += 1
                        _artistsid.append(_artistid)
                if _result['albumid'] not in _albumslist:
                    _albums += 1
                    _albumslist.append(_result['albumid'])
        _setMusicProperties(_artists, _albums, len(_files))
        if RALI_GLOBALS['METHOD'] == 'Last':
            _songslist = sorted(_songslist, key=itemgetter(
                'dateadded'), reverse=True)
        else:
            random.shuffle(_songslist)
        _count = 0
        for _song in _songslist:
            if MONITOR.abortRequested():
                return
            if _count == RALI_GLOBALS['LIMIT']:
                break
            _count += 1
            _setSongPROPERTIES(_song, _count)
        if _count <= RALI_GLOBALS['LIMIT']:
            while _count < RALI_GLOBALS['LIMIT']:
                _count += 1
                _setSongPROPERTIES(None, _count)
    else:
        log(f'## PLAYLIST {RALI_GLOBALS["PLAYLIST"]} COULD NOT BE LOADED ##')
        log(f'JSON RESULT {_json_pl_response}')


def _clearProperties() -> None:
    """Clears any existing window properties for the current playlist

    Returns:
        None
    """
    # Reset window Properties
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Loaded')
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Count')
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Watched')
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Unwatched')
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Artists')
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Albums')
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Songs')
    WINDOW.clearProperty(f'{RALI_GLOBALS["PROPERTY"]}.Type')


def _setMusicProperties(_artists: int, _albums: int, _songs: int) -> None:
    """sets summary porperties of albums in window properties

    Args:
        _artists (int): number of artists
        _albums (int): number of albums
        _songs (int): number of songs
    """
    # Set window Properties
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Artists', str(_artists))
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Albums', str(_albums))
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Songs', str(_songs))
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Type', RALI_GLOBALS['TYPE'])


def _setVideoProperties(_total: int, _watched: int, _unwatched: int) -> None:
    """Sets summary info of videos in window properties

    Args:
        _total (int): Total number of items
        _watched (int): Subtotal items watched
        _unwatched (int): Subtotal items unwatched
    """
    # Set window Properties
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Count', str(_total))
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Watched', str(_watched))
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Unwatched', str(_unwatched))
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Type', RALI_GLOBALS['TYPE'])


def _setTvShowsProperties(_tvshows) -> None:
    """sets tv show-level porperties

    Args:
        _tvshows(_type_): _description_
    """
    # Set window Properties
    _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.TvShows', str(_tvshows))


def _setEpisodeProperties(_episode, _count) -> None:
    """sets Kodi summary window properties for episodes

    Args:
        _episode (dict): details for an episode
        _count (_type_): episode index
    """
    if _episode:
        _json_query = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", '
            '"method": "VideoLibrary.GetEpisodeDetails", '
            '"params": '
            '{"properties": ["streamdetails"], '
            f'"episodeid":{_episode["id"]} }}, '
            '"id": 1}')
        _json_query = json.loads(_json_query)
        if 'episodedetails' in _json_query['result']:
            item = _json_query['result']['episodedetails']
            _episode['streamdetails'] = item['streamdetails']
        episode = ('%.2d' % float(_episode['episode']))
        season = '%.2d' % float(_episode['season'])
        episodeno = f's{season}e{episode}'
        rating = str(round(float(_episode['rating']), 1))
        if 'userrating' in _episode:
            userrating = str(_episode['userrating'])
        else:
            userrating = ''
        if _episode['resume']['position'] > 0 and float(_episode['resume']['total']) > 0:
            resume = 'true'
            played = f'{int((float(_episode["resume"]["position"]) / float(_episode["resume"]["total"])) * 100)}%'
            playedasint = f'{int((float(_episode["resume"]["position"]) / float(_episode["resume"]["total"])) * 100)}'
        else:
            resume = 'false'
            played = '0%'
            playedasint = '0'
        art = _episode['art']
        path = media_path(_episode['file'])
        play = 'RunScript(' + ADDONID + ',episodeid=' + \
            str(_episode.get('id')) + ')'
        runtime = str(int((_episode['runtime'] / 60) + 0.5))
        streaminfo = media_streamdetails(_episode['file'].lower(),
                                         _episode['streamdetails'])
        # autopep8:off
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.DBID'                  , str(_episode.get('id')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title'                 , _episode.get('title',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Episode'               , episode)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.EpisodeNo'             , episodeno)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Season'                , season)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Plot'                  , _episode.get('plot',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.TVshowTitle'           , _episode.get('showtitle',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Rating'                , rating)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.UserRating'            , userrating)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(thumb)'            , art.get('thumb',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(tvshow.fanart)'    , art.get('tvshow.fanart',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(tvshow.poster)'    , art.get('tvshow.poster',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(tvshow.banner)'    , art.get('tvshow.banner',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(tvshow.clearlogo)' , art.get('tvshow.clearlogo',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(tvshow.clearart)'  , art.get('tvshow.clearart',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(tvshow.landscape)' , art.get('tvshow.landscape',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(fanart)'           , art.get('tvshow.fanart',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(poster)'           , art.get('tvshow.poster',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(banner)'           , art.get('tvshow.banner',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(clearlogo)'        , art.get('tvshow.clearlogo',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(clearart)'         , art.get('tvshow.clearart',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(landscape)'        , art.get('tvshow.landscape',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Resume'                , resume)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Watched'               , _episode.get('watched',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Runtime'               , runtime)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Premiered'             , _episode.get('firstaired',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.PercentPlayed'         , played)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Played'                , playedasint)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.File'                  , _episode.get('file',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.MPAA'                  , _episode.get('mpaa',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Studio'                , ' / '.join(_episode.get('studio','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Path'                  , path)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Play'                  , play)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoCodec'            , streaminfo['videocodec'])
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoResolution'       , streaminfo['videoresolution'])
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.VideoAspect'           , streaminfo['videoaspect'])
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.AudioCodec'            , streaminfo['audiocodec'])
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.AudioChannels'         , str(streaminfo['audiochannels']))
        # autopep8:on

    else:
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title', '')


def _setAlbumPROPERTIES(_album: dict, _count: int) -> None:
    """Sets the window properties for playlist albums
    """
    if _album:
        # Set window Properties
        _rating = str(_album['rating'])
        if 'userrating' in _album:
            _userrating = str(_album['userrating'])
        else:
            _userrating = ''
        if _rating == '48':
            _rating = ''
        play = 'RunScript(' + ADDONID + ',albumid=' + \
            str(_album.get('albumid')) + ')'
        path = 'musicdb://albums/' + str(_album.get('albumid')) + '/'
        # autopep8:off
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title'       , _album.get('title',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Artist'      , ' / '.join(_album.get('artist','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Genre'       , ' / '.join(_album.get('genre','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Theme'       , ' / '.join(_album.get('theme','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Mood'        , ' / '.join(_album.get('mood','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Style'       , ' / '.join(_album.get('style','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Type'        , _album.get('type',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Year'        , str(_album.get('year','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.RecordLabel' , _album.get('albumlabel',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Description' , _album.get('description',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Rating'      , _rating)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.UserRating'  , _userrating)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(thumb)'  , _album.get('thumbnail',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(fanart)' , _album.get('fanart',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Play'        , play)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.LibraryPath' , path)
    else:
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title'       , '')
    # autopep8:on


def _setSongPROPERTIES(_song: dict, _count: int) -> None:
    """Sets the window properties for playlist songs
    """
    if _song:
        # Set window Properties
        _rating = str(_song['rating'])
        if 'userrating' in _song:
            _userrating = str(_song['userrating'])
        else:
            _userrating = ''
        if _rating == '48':
            _rating = ''
        play = 'RunScript(' + ADDONID + ',songid=' + \
            str(_song.get('songid')) + ')'
        path = 'musicdb://songs/' + str(_song.get('songid')) + '/'
        # autopep8:off
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title'       , _song.get('title',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Artist'      , ' / '.join(_song.get('artist','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Genre'       , ' / '.join(_song.get('genre','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Year'        , str(_song.get('year','')))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Description' , _song.get('comment',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Rating'      , _rating)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.UserRating'  , _userrating)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(thumb)'  , _song.get('thumbnail',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Art(fanart)' , _song.get('fanart',''))
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Play'        , play)
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.LibraryPath' , path)
    else:
        _setProperty(f'{RALI_GLOBALS["PROPERTY"]}.{_count}.Title'       , '')
    # autopep8:on


def _setProperty(_property: str, _value: str) -> None:
    """Calls kodi setProperty method

    Args:
        _property (str): property key
        _value (str): value
    """
    # global WINDOW
    # Set window Properties
    WINDOW.setProperty(_property, _value)


def _parse_argv() -> None:
    """Gets arguments pass by skin call to RunScript()

        Arguments are retrieved into a dict for processing.
        -  If a library item id is passed, starts playback of item
        -  Otherwise will set script global variables
        -  If passed playlist will determine type and order
    """
    try:
        params = dict(arg.split('=') for arg in sys.argv[1].split('&'))
    except Exception:
        params = {}
    if params.get('movieid'):
        # xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Player.Open", "params": { "item": { "movieid": %d }, "options":{ "resume": true } }, "id": 1 }' % int(params.get("movieid")))
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", '
                            '"method": "Player.Open", '
                            '"params": '
                            '{ "item": { "movieid": %d }, '
                            '"options":{ "resume": %s } }, '
                            '"id": 1 }' % (
                                int(params.get("movieid", "")), params.get("resume", "true")))
    elif params.get('episodeid'):
        # xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Player.Open", "params": { "item": { "episodeid": %d }, "options":{ "resume": true }  }, "id": 1 }' % int(params.get("episodeid")))
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", '
                            '"method": "Player.Open", '
                            '"params": '
                            '{ "item": { "episodeid": %d }, '
                            '"options":{ "resume": %s }  }, '
                            '"id": 1 }' % (int(params.get("episodeid", "")), params.get("resume", "true")))
    elif params.get('musicvideoid'):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", '
                            '"method": "Player.Open", '
                            '"params": { "item": { "musicvideoid": %d } }, '
                            '"id": 1 }' % int(params.get("musicvideoid")))
    elif params.get('albumid'):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", '
                            '"method": "Player.Open", '
                            '"params": { "item": { "albumid": %d } }, '
                            '"id": 1 }' % int(params.get("albumid")))
    elif params.get('songid'):
        xbmc.executeJSONRPC(
            '{ "jsonrpc": "2.0", '
            '"method": "Player.Open", '
            '"params": { "item": { "songid": %d } }, '
            '"id": 1 }' % int(params.get("songid")))
    else:
        # Extract parameters
        for arg in sys.argv:
            param = str(arg)
            if 'limit=' in param:
                RALI_GLOBALS['LIMIT'] = int(param.replace('limit=', ''))
            elif 'menu=' in param:
                RALI_GLOBALS['MENU'] = param.replace('menu=', '')
            elif 'method=' in param:
                RALI_GLOBALS['METHOD'] = param.replace('method=', '')
            elif 'playlist=' in param:
                RALI_GLOBALS['PLAYLIST'] = param.replace('playlist=', '')
                RALI_GLOBALS['PLAYLIST'] = RALI_GLOBALS['PLAYLIST'].replace(
                    '"', '')
            elif 'property=' in param:
                RALI_GLOBALS['PROPERTY'] = param.replace('property=', '')
            elif 'type=' in param:
                RALI_GLOBALS['TYPE'] = param.replace('type=', '')
            elif 'unwatched=' in param:
                RALI_GLOBALS['UNWATCHED'] = param.replace('unwatched=', '')
                if RALI_GLOBALS['UNWATCHED'] == '':
                    RALI_GLOBALS['UNWATCHED'] = 'False'
            elif 'resume=' in param:
                RALI_GLOBALS['RESUME'] = param.replace('resume=', '')
        if RALI_GLOBALS['PLAYLIST'] != '' and xbmcvfs.exists(xbmcvfs.translatePath(RALI_GLOBALS['PLAYLIST'])):
            _getPlaylistType()
        if RALI_GLOBALS['PROPERTY'] == '':
            RALI_GLOBALS['PROPERTY'] = f'Playlist{RALI_GLOBALS["METHOD"]}{RALI_GLOBALS["TYPE"]}{RALI_GLOBALS["MENU"]}'


def media_streamdetails(filename: str, streamdetails: dict) -> dict:
    """gets stream details from Kodi library computes the video resolution

    Args:
        filename (str): filename
        streamdetails (dict): A dict from the json rpc call

    Returns:
        dict: stream details
    """
    info = {}
    video = streamdetails['video']
    audio = streamdetails['audio']
    if '3d' in filename:
        info['videoresolution'] = '3d'
    elif video:
        # videowidth = video[0]['width']
        videoheight = video[0]['height']
        if (video[0]['width'] <= 720 and videoheight <= 480):
            info['videoresolution'] = '480'
        elif (video[0]['width'] <= 768 and videoheight <= 576):
            info['videoresolution'] = '576'
        elif (video[0]['width'] <= 960 and videoheight <= 544):
            info['videoresolution'] = '540'
        elif (video[0]['width'] <= 1280 and videoheight <= 720):
            info['videoresolution'] = '720'
        elif (video[0]['width'] >= 1281 and videoheight >= 721):
            info['videoresolution'] = '1080'
        else:
            info['videoresolution'] = ''
    elif (('dvd') in filename and not ('hddvd' or 'hd-dvd') in filename) or (filename.endswith('.vob' or '.ifo')):
        info['videoresolution'] = '576'
    elif (('bluray' or 'blu-ray' or 'brrip' or 'bdrip' or 'hddvd' or 'hd-dvd') in filename):
        info['videoresolution'] = '1080'
    else:
        info['videoresolution'] = '1080'
    if video and 'duration' in video[0]:
        info['duration'] = video[0]['duration']
    else:
        info['duration'] = 0
    if video:
        info['videocodec'] = video[0]['codec']
        if (video[0]['aspect'] < 1.4859):
            info['videoaspect'] = '1.33'
        elif (video[0]['aspect'] < 1.7190):
            info['videoaspect'] = '1.66'
        elif (video[0]['aspect'] < 1.8147):
            info['videoaspect'] = '1.78'
        elif (video[0]['aspect'] < 2.0174):
            info['videoaspect'] = '1.85'
        elif (video[0]['aspect'] < 2.2738):
            info['videoaspect'] = '2.20'
        else:
            info['videoaspect'] = '2.35'
    else:
        info['videocodec'] = ''
        info['videoaspect'] = ''
    if audio:
        info['audiocodec'] = audio[0]['codec']
        info['audiochannels'] = audio[0]['channels']
    else:
        info['audiocodec'] = ''
        info['audiochannels'] = ''
    return info


def media_path(raw_path: str) -> str:
    """gets actual path for the media item

    Args:
        raw_path (str): The Kodi path for the media item

    Returns:
        str: The path fixed for stacked or RARed items
    """
    # Check for stacked movies
    try:
        raw_path = os.path.split(raw_path)[0].rsplit(' , ', 1)[1].replace(',,', ',')
    except Exception:
        raw_path = os.path.split(raw_path)[0]
    # Fixes problems with rared movies and multipath
    if raw_path.startswith('rar://'):
        raw_pathlist = [os.path.split(urllib.request.url2pathname(
            raw_path.replace('rar://', '')))[0]]
    elif raw_path.startswith('multipath://'):
        temp_path = raw_path.replace('multipath://', '').split('%2f/')
        raw_pathlist = []
        for item in temp_path:
            raw_pathlist.append(urllib.request.url2pathname(item))
    else:
        raw_pathlist = [raw_path]
    return raw_pathlist[0]


def run():
    """Main entry point for the addon
    """

    # Parse argv for any preferences
    _parse_argv()
    # Clear Properties for playlist PROPERTY from _parse_argv()
    _clearProperties()
    # Get movies and fill Properties
    if RALI_GLOBALS['TYPE'] == 'Movie':
        _getMovies()
    elif RALI_GLOBALS['TYPE'] == 'Episode':
        if RALI_GLOBALS['PLAYLIST'] == '':
            _getEpisodes()
        else:
            _getEpisodesFromPlaylist()
    elif RALI_GLOBALS['TYPE'] == 'Music':
        _getMusicFromPlaylist()
    elif RALI_GLOBALS['TYPE'] == 'MusicVideo':
        _getMusicVideosFromPlaylist()
    if RALI_GLOBALS['TYPE'] != 'Invalid':
        # skin can check this to verify properties available
        WINDOW.setProperty(f'{RALI_GLOBALS["PROPERTY"]}.Loaded', 'true')
        log(f'Loading Playlist{RALI_GLOBALS["METHOD"]}{RALI_GLOBALS["TYPE"]}{RALI_GLOBALS["MENU"]} '
            f'started at {time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(START_TIME))} '
            f'and took {_timeTook(START_TIME)} (Nexus+ {JSON_RPC_NEXUS})')
    else:
        log(
            f'Unable to process the {RALI_GLOBALS["METHOD"]}{RALI_GLOBALS["MENU"]} playlist')

